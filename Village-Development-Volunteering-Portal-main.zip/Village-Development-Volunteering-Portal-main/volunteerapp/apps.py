from django.apps import AppConfig


class VolunteerappConfig(AppConfig):
    name = 'volunteerapp'
